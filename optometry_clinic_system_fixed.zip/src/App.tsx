import { Authenticated, Unauthenticated, useQuery, useMutation } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import RoleBasedSignUpForm from "./components/RoleBasedSignUpForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster } from "sonner";
import { useState } from "react";
import Dashboard from "./components/Dashboard";
import CustomersSection from "./components/CustomersSection";
import InventorySection from "./components/InventorySection";
import AppointmentsSection from "./components/AppointmentsSection";
import OrdersSection from "./components/OrdersSection";
import AnalyticsSection from "./components/AnalyticsSection";
import UserManagementSection from "./components/UserManagementSection";

export default function App() {
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Authenticated>
        <ClinicApp />
      </Authenticated>
      <Unauthenticated>
        <div className="min-h-screen flex items-center justify-center">
          <div className="w-full max-w-md mx-auto p-8">
            <div className="text-center mb-8">
              <h1 className="text-3xl font-bold text-blue-600 mb-2">VisionCare Clinic</h1>
              <p className="text-gray-600">Advanced Optometry Management System</p>
              <p className="text-sm text-gray-500 mt-2">
                Smart scheduling • Role-based access • Analytics & Reports
              </p>
            </div>
            <SignInForm />
          </div>
        </div>
      </Unauthenticated>
      <Toaster />
    </div>
  );
}

function ClinicApp() {
  const [activeSection, setActiveSection] = useState("dashboard");
  const [showRoleSignup, setShowRoleSignup] = useState(false);
  const loggedInUser = useQuery(api.auth.loggedInUser);
  const currentProfile = useQuery(api.profiles.getCurrentProfile);
  const createDefaultProfile = useMutation(api.profiles.createDefaultProfile);

  if (loggedInUser === undefined || currentProfile === undefined) {
    return (
      <div className="min-h-screen flex justify-center items-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  // If user exists but no profile, create one
  if (loggedInUser && currentProfile === null) {
    createDefaultProfile({});
    return (
      <div className="min-h-screen flex justify-center items-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Setting up your profile...</p>
        </div>
      </div>
    );
  }

  const userRole = currentProfile?.role || "staff";

  const navigationItems = [
    { id: "dashboard", label: "📊 Dashboard", roles: ["admin", "staff", "doctor"] },
    { id: "customers", label: "👥 Customers", roles: ["admin", "staff", "doctor"] },
    { id: "appointments", label: "📅 Smart Appointments", roles: ["admin", "staff", "doctor"] },
    { id: "orders", label: "📦 Orders", roles: ["admin", "staff"] },
    { id: "inventory", label: "👓 Inventory", roles: ["admin", "staff"] },
    { id: "analytics", label: "📈 Analytics", roles: ["admin"] },
    { id: "users", label: "👤 User Management", roles: ["admin"] },
  ];

  const allowedItems = navigationItems.filter(item => item.roles.includes(userRole));

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <h1 className="text-2xl font-bold text-blue-600">VisionCare Pro</h1>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              {currentProfile?.role === "admin" && (
                <button
                  onClick={() => setShowRoleSignup(true)}
                  className="text-sm bg-green-600 text-white px-3 py-1 rounded hover:bg-green-700"
                >
                  Add User
                </button>
              )}
              <div className="text-right">
                <div className="text-sm text-gray-700">
                  {currentProfile?.firstName} {currentProfile?.lastName}
                </div>
                <div className="text-xs text-gray-500 capitalize">
                  {currentProfile?.role} • {loggedInUser?.email}
                </div>
              </div>
              <SignOutButton />
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <nav className="w-64 bg-white shadow-sm min-h-screen">
          <div className="p-4">
            <ul className="space-y-2">
              {allowedItems.map((item) => (
                <li key={item.id}>
                  <button
                    onClick={() => setActiveSection(item.id)}
                    className={`w-full text-left px-4 py-2 rounded-lg transition-colors ${
                      activeSection === item.id
                        ? "bg-blue-100 text-blue-700"
                        : "text-gray-700 hover:bg-gray-100"
                    }`}
                  >
                    {item.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </nav>

        {/* Main Content */}
        <main className="flex-1 p-8">
          {activeSection === "dashboard" && <Dashboard />}
          {activeSection === "customers" && <CustomersSection />}
          {activeSection === "inventory" && <InventorySection />}
          {activeSection === "appointments" && <AppointmentsSection />}
          {activeSection === "orders" && <OrdersSection />}
          {activeSection === "analytics" && <AnalyticsSection />}
          {activeSection === "users" && <UserManagementSection />}
        </main>
      </div>
      
      {/* Role-based Signup Modal */}
      {showRoleSignup && (
        <RoleBasedSignUpForm onClose={() => setShowRoleSignup(false)} />
      )}
    </div>
  );
}
