import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

export default function UserManagementSection() {
  const currentProfile = useQuery(api.profiles.getCurrentProfile);
  const profiles = useQuery(api.profiles.listProfiles);
  const updateUserRole = useMutation(api.profiles.updateUserRole);

  const [editingProfile, setEditingProfile] = useState<any>(null);

  const handleRoleUpdate = async (profileId: string, newRole: string) => {
    try {
      await updateUserRole({ profileId: profileId as any, role: newRole });
      toast.success("User role updated successfully");
    } catch (error: any) {
      toast.error(error.message || "Failed to update user role");
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case "admin": return "bg-red-100 text-red-800";
      case "doctor": return "bg-blue-100 text-blue-800";
      case "staff": return "bg-green-100 text-green-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getRolePermissions = (role: string) => {
    switch (role) {
      case "admin":
        return "Full system access, user management, all reports";
      case "doctor":
        return "Patient records, appointments, medical history";
      case "staff":
        return "Basic operations, inventory, customer service";
      default:
        return "Limited access";
    }
  };

  if (!currentProfile || currentProfile.role !== "admin") {
    return (
      <div className="space-y-6">
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <div className="flex">
            <div className="flex-shrink-0">
              <span className="text-yellow-400 text-xl">⚠️</span>
            </div>
            <div className="ml-3">
              <h3 className="text-sm font-medium text-yellow-800">Access Restricted</h3>
              <div className="mt-2 text-sm text-yellow-700">
                <p>You need administrator privileges to access user management.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold text-gray-900">User Management</h2>
        <p className="text-gray-600">Manage user roles and permissions</p>
      </div>

      {/* Role Information */}
      <div className="bg-white p-6 rounded-lg shadow-sm border">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Role Permissions</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 border border-red-200 rounded-lg bg-red-50">
            <div className="flex items-center mb-2">
              <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-red-100 text-red-800">
                Admin
              </span>
            </div>
            <p className="text-sm text-gray-600">
              Full system access, user management, all reports, system settings
            </p>
          </div>
          <div className="p-4 border border-blue-200 rounded-lg bg-blue-50">
            <div className="flex items-center mb-2">
              <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-blue-100 text-blue-800">
                Doctor
              </span>
            </div>
            <p className="text-sm text-gray-600">
              Patient records, appointments, medical history, prescriptions
            </p>
          </div>
          <div className="p-4 border border-green-200 rounded-lg bg-green-50">
            <div className="flex items-center mb-2">
              <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">
                Staff
              </span>
            </div>
            <p className="text-sm text-gray-600">
              Basic operations, inventory management, customer service
            </p>
          </div>
        </div>
      </div>

      {/* Users List */}
      <div className="bg-white rounded-lg shadow-sm border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  User
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Role
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Permissions
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {profiles?.map((profile) => (
                <tr key={profile._id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div>
                      <div className="text-sm font-medium text-gray-900">
                        {profile.firstName} {profile.lastName}
                      </div>
                      <div className="text-sm text-gray-500">
                        {profile.department && `${profile.department} • `}
                        {profile.phone}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <select
                      value={profile.role}
                      onChange={(e) => handleRoleUpdate(profile._id, e.target.value)}
                      className={`text-xs font-semibold rounded-full px-2 py-1 border-0 ${getRoleColor(profile.role)}`}
                      disabled={profile._id === currentProfile._id} // Can't change own role
                    >
                      <option value="staff">Staff</option>
                      <option value="doctor">Doctor</option>
                      <option value="admin">Admin</option>
                    </select>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm text-gray-600">
                      {getRolePermissions(profile.role)}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                      profile.isActive 
                        ? "bg-green-100 text-green-800" 
                        : "bg-red-100 text-red-800"
                    }`}>
                      {profile.isActive ? "Active" : "Inactive"}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    {profile._id === currentProfile._id ? (
                      <span className="text-gray-400">Current User</span>
                    ) : (
                      <button
                        onClick={() => setEditingProfile(profile)}
                        className="text-blue-600 hover:text-blue-900"
                      >
                        Edit
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {!profiles || profiles.length === 0 && (
          <div className="text-center py-8 text-gray-500">
            No users found.
          </div>
        )}
      </div>

      {/* Security Notice */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <div className="flex">
          <div className="flex-shrink-0">
            <span className="text-blue-400 text-xl">🔒</span>
          </div>
          <div className="ml-3">
            <h3 className="text-sm font-medium text-blue-800">Security & Privacy</h3>
            <div className="mt-2 text-sm text-blue-700">
              <ul className="list-disc list-inside space-y-1">
                <li>All patient data is encrypted and access-controlled</li>
                <li>User actions are logged for audit purposes</li>
                <li>Role changes take effect immediately</li>
                <li>Only administrators can modify user roles</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
