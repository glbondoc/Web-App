import { useState, useEffect } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";
import type { Id } from "../../convex/_generated/dataModel";

interface SmartAppointmentFormProps {
  onClose: () => void;
  editingAppointment?: any;
  onSuccess: () => void;
}

export default function SmartAppointmentForm({ onClose, editingAppointment, onSuccess }: SmartAppointmentFormProps) {
  const [formData, setFormData] = useState({
    customerId: "" as Id<"customers">,
    appointmentDate: "",
    appointmentTime: "",
    serviceType: "eye-exam",
    notes: "",
    doctorName: "",
  });

  const [suggestedSlots, setSuggestedSlots] = useState<any[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);

  const customers = useQuery(api.customers.list) || [];
  const createAppointment = useMutation(api.appointments.create);
  const updateAppointment = useMutation(api.appointments.update);
  const checkAvailability = useQuery(
    api.appointments.checkAvailability,
    formData.appointmentDate && formData.appointmentTime
      ? {
          date: formData.appointmentDate,
          time: formData.appointmentTime,
          duration: getServiceDuration(formData.serviceType),
          doctorName: formData.doctorName || undefined,
          excludeId: editingAppointment?._id,
        }
      : "skip"
  );

  const suggestedSlotsQuery = useQuery(
    api.appointments.getSuggestedSlots,
    formData.appointmentDate && formData.serviceType
      ? {
          date: formData.appointmentDate,
          serviceType: formData.serviceType,
          doctorName: formData.doctorName || undefined,
        }
      : "skip"
  );

  useEffect(() => {
    if (editingAppointment) {
      setFormData({
        customerId: editingAppointment.customerId,
        appointmentDate: editingAppointment.appointmentDate,
        appointmentTime: editingAppointment.appointmentTime,
        serviceType: editingAppointment.serviceType,
        notes: editingAppointment.notes || "",
        doctorName: editingAppointment.doctorName || "",
      });
    }
  }, [editingAppointment]);

  useEffect(() => {
    if (suggestedSlotsQuery) {
      setSuggestedSlots(suggestedSlotsQuery);
    }
  }, [suggestedSlotsQuery]);

  function getServiceDuration(serviceType: string): number {
    const durations: Record<string, number> = {
      "eye-exam": 60,
      "contact-fitting": 45,
      "frame-selection": 30,
    };
    return durations[serviceType] || 30;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (checkAvailability && !checkAvailability.available) {
      toast.error("This time slot is not available. Please choose a different time.");
      return;
    }

    try {
      if (editingAppointment) {
        await updateAppointment({
          id: editingAppointment._id,
          ...formData,
          status: editingAppointment.status,
        });
        toast.success("Appointment updated successfully");
      } else {
        await createAppointment(formData);
        toast.success("Appointment scheduled successfully");
      }
      onSuccess();
      onClose();
    } catch (error: any) {
      toast.error(error.message || "Failed to save appointment");
    }
  };

  const handleTimeSlotSelect = (time: string) => {
    setFormData({ ...formData, appointmentTime: time });
    setShowSuggestions(false);
  };

  const isTimeSlotAvailable = checkAvailability?.available !== false;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white p-6 rounded-lg shadow-xl max-w-2xl w-full mx-4 max-h-[90vh] overflow-y-auto">
        <h3 className="text-xl font-semibold mb-4">
          {editingAppointment ? "Edit Appointment" : "Schedule Smart Appointment"}
        </h3>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Customer *
            </label>
            <select
              required
              value={formData.customerId}
              onChange={(e) => setFormData({ ...formData, customerId: e.target.value as Id<"customers"> })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">Select a customer</option>
              {customers.map((customer) => (
                <option key={customer._id} value={customer._id}>
                  {customer.firstName} {customer.lastName} - {customer.email}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Service Type *
            </label>
            <select
              required
              value={formData.serviceType}
              onChange={(e) => setFormData({ ...formData, serviceType: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="eye-exam">Eye Exam</option>
              <option value="contact-fitting">Contact Fitting</option>
              <option value="frame-selection">Frame Selection</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Doctor Name
            </label>
            <input
              type="text"
              value={formData.doctorName}
              onChange={(e) => setFormData({ ...formData, doctorName: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Optional - leave blank for any doctor"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Date *
              </label>
              <input
                type="date"
                required
                value={formData.appointmentDate}
                onChange={(e) => setFormData({ ...formData, appointmentDate: e.target.value })}
                min={new Date().toISOString().split('T')[0]}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Time *
              </label>
              <div className="relative">
                <input
                  type="time"
                  required
                  value={formData.appointmentTime}
                  onChange={(e) => setFormData({ ...formData, appointmentTime: e.target.value })}
                  className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                    !isTimeSlotAvailable ? 'border-red-300 bg-red-50' : 'border-gray-300'
                  }`}
                />
                {!isTimeSlotAvailable && (
                  <div className="absolute right-2 top-2 text-red-500">
                    ⚠️
                  </div>
                )}
              </div>
              {!isTimeSlotAvailable && (
                <p className="text-red-600 text-sm mt-1">
                  This time slot is not available
                </p>
              )}
            </div>
          </div>

          {/* Suggested Time Slots */}
          {formData.appointmentDate && suggestedSlots.length > 0 && (
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="block text-sm font-medium text-gray-700">
                  Suggested Available Times
                </label>
                <button
                  type="button"
                  onClick={() => setShowSuggestions(!showSuggestions)}
                  className="text-blue-600 text-sm hover:text-blue-800"
                >
                  {showSuggestions ? "Hide" : "Show"} suggestions
                </button>
              </div>
              
              {showSuggestions && (
                <div className="grid grid-cols-3 gap-2 p-3 bg-gray-50 rounded-lg">
                  {suggestedSlots.slice(0, 9).map((slot, index) => (
                    <button
                      key={index}
                      type="button"
                      onClick={() => handleTimeSlotSelect(slot.time)}
                      className="px-3 py-2 text-sm bg-white border border-gray-300 rounded hover:bg-blue-50 hover:border-blue-300 transition-colors"
                    >
                      {slot.time}
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Notes
            </label>
            <textarea
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              rows={3}
              placeholder="Any special notes or requirements..."
            />
          </div>

          <div className="flex justify-end space-x-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-700 bg-gray-200 rounded-lg hover:bg-gray-300 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!isTimeSlotAvailable}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
            >
              {editingAppointment ? "Update" : "Schedule"} Appointment
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
