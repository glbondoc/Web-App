import { query, mutation } from "./_generated/server";
import { v } from "convex/values";

export const list = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db.query("inventory").order("desc").collect();
  },
});

export const get = query({
  args: { id: v.id("inventory") },
  handler: async (ctx, args) => {
    return await ctx.db.get(args.id);
  },
});

export const create = mutation({
  args: {
    brand: v.string(),
    model: v.string(),
    frameType: v.string(),
    frameStyle: v.string(),
    color: v.string(),
    size: v.string(),
    price: v.number(),
    cost: v.number(),
    quantity: v.number(),
    minStock: v.number(),
    description: v.optional(v.string()),
    supplier: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("inventory", args);
  },
});

export const update = mutation({
  args: {
    id: v.id("inventory"),
    brand: v.string(),
    model: v.string(),
    frameType: v.string(),
    frameStyle: v.string(),
    color: v.string(),
    size: v.string(),
    price: v.number(),
    cost: v.number(),
    quantity: v.number(),
    minStock: v.number(),
    description: v.optional(v.string()),
    supplier: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const { id, ...updates } = args;
    return await ctx.db.patch(id, updates);
  },
});

export const remove = mutation({
  args: { id: v.id("inventory") },
  handler: async (ctx, args) => {
    return await ctx.db.delete(args.id);
  },
});

export const updateStock = mutation({
  args: {
    id: v.id("inventory"),
    quantity: v.number(),
  },
  handler: async (ctx, args) => {
    return await ctx.db.patch(args.id, { quantity: args.quantity });
  },
});

export const getLowStock = query({
  args: {},
  handler: async (ctx) => {
    const items = await ctx.db.query("inventory").collect();
    return items.filter(item => item.quantity <= item.minStock);
  },
});

export const getByFrameType = query({
  args: { frameType: v.string() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("inventory")
      .withIndex("by_frame_type", (q) => q.eq("frameType", args.frameType))
      .collect();
  },
});
