import { cronJobs } from "convex/server";
import { internal } from "./_generated/api";

const crons = cronJobs();

// Send pending notifications every 5 minutes
crons.interval(
  "send notifications",
  { minutes: 5 },
  internal.notifications.sendPendingNotifications,
  {}
);

// Generate daily reports at midnight
crons.cron(
  "generate daily reports",
  "0 0 * * *", // Every day at midnight
  internal.analytics.generateDailyReportInternal,
  { date: new Date().toISOString().split('T')[0] }
);

export default crons;
