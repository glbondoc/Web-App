import { query, mutation, action, internalAction } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";
import { api } from "./_generated/api";

export const sendPendingNotifications = internalAction({
  args: {},
  handler: async (ctx) => {
    const now = new Date().toISOString();
    const pendingNotifications = await ctx.runQuery(api.notifications.getPending, { before: now });

    for (const notification of pendingNotifications) {
      try {
        if (notification.method === "email") {
          // Here you would integrate with your email service
          console.log(`Sending email to ${notification.recipientId}: ${notification.message}`);
        } else if (notification.method === "sms") {
          // Here you would integrate with your SMS service
          console.log(`Sending SMS to ${notification.recipientId}: ${notification.message}`);
        }

        await ctx.runMutation(api.notifications.markAsSent, {
          id: notification._id,
        });
      } catch (error) {
        await ctx.runMutation(api.notifications.markAsFailed, {
          id: notification._id,
        });
      }
    }
  },
});

export const getPending = query({
  args: { before: v.string() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("notifications")
      .withIndex("by_status", (q) => q.eq("status", "pending"))
      .filter((q) => q.lte(q.field("scheduledFor"), args.before))
      .collect();
  },
});

export const markAsSent = mutation({
  args: { id: v.id("notifications") },
  handler: async (ctx, args) => {
    await ctx.db.patch(args.id, {
      status: "sent",
      sentAt: new Date().toISOString(),
    });
  },
});

export const markAsFailed = mutation({
  args: { id: v.id("notifications") },
  handler: async (ctx, args) => {
    await ctx.db.patch(args.id, {
      status: "failed",
    });
  },
});

export const createNotification = mutation({
  args: {
    type: v.string(),
    recipientId: v.union(v.id("customers"), v.id("users")),
    recipientType: v.string(),
    title: v.string(),
    message: v.string(),
    method: v.string(),
    scheduledFor: v.string(),
    relatedId: v.optional(v.union(v.id("appointments"), v.id("orders"))),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("notifications", {
      ...args,
      status: "pending",
    });
  },
});
