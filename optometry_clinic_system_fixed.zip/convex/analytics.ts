import { query, mutation, internalMutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const generateDailyReport = mutation({
  args: { date: v.string() },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    // Get appointments for the day
    const appointments = await ctx.db
      .query("appointments")
      .withIndex("by_date", (q) => q.eq("appointmentDate", args.date))
      .collect();

    // Get orders for the day
    const orders = await ctx.db
      .query("orders")
      .filter((q) => q.eq(q.field("orderDate"), args.date))
      .collect();

    // Get new customers for the day
    const customers = await ctx.db.query("customers").collect();
    const newCustomers = customers.filter(c => c.lastVisit === args.date).length;

    const data = {
      totalSales: orders.reduce((sum, order) => sum + order.totalAmount, 0),
      appointmentsScheduled: appointments.length,
      appointmentsCompleted: appointments.filter(apt => apt.status === "completed").length,
      noShows: appointments.filter(apt => apt.status === "no-show").length,
      newCustomers,
    };

    // Store or update analytics record
    const existing = await ctx.db
      .query("analytics")
      .withIndex("by_date", (q) => q.eq("date", args.date))
      .filter((q) => q.eq(q.field("type"), "daily_sales"))
      .first();

    if (existing) {
      await ctx.db.patch(existing._id, { data });
    } else {
      await ctx.db.insert("analytics", {
        date: args.date,
        type: "daily_sales",
        data,
      });
    }

    return data;
  },
});

export const getReports = query({
  args: {
    startDate: v.string(),
    endDate: v.string(),
    type: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    return await ctx.db
      .query("analytics")
      .withIndex("by_type", (q) => q.eq("type", args.type))
      .filter((q) => 
        q.and(
          q.gte(q.field("date"), args.startDate),
          q.lte(q.field("date"), args.endDate)
        )
      )
      .collect();
  },
});

export const getSalesReport = query({
  args: {
    startDate: v.string(),
    endDate: v.string(),
  },
  handler: async (ctx, args) => {
    const orders = await ctx.db.query("orders").collect();
    
    const filteredOrders = orders.filter(order => 
      order.orderDate >= args.startDate && order.orderDate <= args.endDate
    );

    const totalSales = filteredOrders.reduce((sum, order) => sum + order.totalAmount, 0);
    const totalOrders = filteredOrders.length;
    const averageOrderValue = totalOrders > 0 ? totalSales / totalOrders : 0;

    // Group by status
    const statusBreakdown = filteredOrders.reduce((acc, order) => {
      acc[order.status] = (acc[order.status] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return {
      totalSales,
      totalOrders,
      averageOrderValue,
      statusBreakdown,
      orders: filteredOrders,
    };
  },
});

export const getInventoryReport = query({
  args: {},
  handler: async (ctx) => {
    const inventory = await ctx.db.query("inventory").collect();
    
    const totalItems = inventory.length;
    const totalValue = inventory.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const lowStockItems = inventory.filter(item => item.quantity <= item.minStock);
    const outOfStockItems = inventory.filter(item => item.quantity === 0);

    // Group by frame type
    const typeBreakdown = inventory.reduce((acc, item) => {
      acc[item.frameType] = (acc[item.frameType] || 0) + item.quantity;
      return acc;
    }, {} as Record<string, number>);

    return {
      totalItems,
      totalValue,
      lowStockCount: lowStockItems.length,
      outOfStockCount: outOfStockItems.length,
      typeBreakdown,
      lowStockItems,
      outOfStockItems,
    };
  },
});

export const generateDailyReportInternal = internalMutation({
  args: { date: v.string() },
  handler: async (ctx, args) => {
    const appointments = await ctx.db
      .query("appointments")
      .withIndex("by_date", (q) => q.eq("appointmentDate", args.date))
      .collect();

    const orders = await ctx.db
      .query("orders")
      .filter((q) => q.eq(q.field("orderDate"), args.date))
      .collect();

    const customers = await ctx.db.query("customers").collect();
    const newCustomers = customers.filter(c => c.lastVisit === args.date).length;

    const data = {
      totalSales: orders.reduce((sum, order) => sum + order.totalAmount, 0),
      appointmentsScheduled: appointments.length,
      appointmentsCompleted: appointments.filter(apt => apt.status === "completed").length,
      noShows: appointments.filter(apt => apt.status === "no-show").length,
      newCustomers,
    };

    const existing = await ctx.db
      .query("analytics")
      .withIndex("by_date", (q) => q.eq("date", args.date))
      .filter((q) => q.eq(q.field("type"), "daily_sales"))
      .first();

    if (existing) {
      await ctx.db.patch(existing._id, { data });
    } else {
      await ctx.db.insert("analytics", {
        date: args.date,
        type: "daily_sales",
        data,
      });
    }

    return data;
  },
});
