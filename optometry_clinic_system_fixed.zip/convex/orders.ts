import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const list = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const orders = await ctx.db.query("orders").order("desc").collect();
    
    const ordersWithCustomers = await Promise.all(
      orders.map(async (order) => {
        const customer = await ctx.db.get(order.customerId);
        return { ...order, customer };
      })
    );

    return ordersWithCustomers;
  },
});

export const get = query({
  args: { id: v.id("orders") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    return await ctx.db.get(args.id);
  },
});

export const create = mutation({
  args: {
    customerId: v.id("customers"),
    items: v.array(v.object({
      inventoryId: v.id("inventory"),
      quantity: v.number(),
      price: v.number(),
    })),
    notes: v.optional(v.string()),
    expectedDate: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    // Generate order number
    const orderNumber = `ORD-${Date.now()}`;
    
    // Calculate total amount and get item names
    let totalAmount = 0;
    const itemsWithNames = [];
    
    for (const item of args.items) {
      const inventoryItem = await ctx.db.get(item.inventoryId);
      if (!inventoryItem) {
        throw new Error(`Inventory item not found: ${item.inventoryId}`);
      }
      
      totalAmount += item.price * item.quantity;
      itemsWithNames.push({
        ...item,
        itemName: `${inventoryItem.brand} ${inventoryItem.model} - ${inventoryItem.color}`,
      });
      
      // Update inventory quantity
      await ctx.db.patch(item.inventoryId, {
        quantity: inventoryItem.quantity - item.quantity,
      });
    }

    return await ctx.db.insert("orders", {
      customerId: args.customerId,
      orderNumber,
      items: itemsWithNames,
      totalAmount,
      status: "pending",
      orderDate: new Date().toISOString().split('T')[0],
      expectedDate: args.expectedDate,
      notes: args.notes,
      createdBy: userId,
    });
  },
});

export const updateStatus = mutation({
  args: {
    id: v.id("orders"),
    status: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const updates: any = { status: args.status };
    
    if (args.status === "completed") {
      updates.completedDate = new Date().toISOString().split('T')[0];
    }

    return await ctx.db.patch(args.id, updates);
  },
});

export const remove = mutation({
  args: { id: v.id("orders") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    // Get the order to restore inventory
    const order = await ctx.db.get(args.id);
    if (order) {
      // Restore inventory quantities
      for (const item of order.items) {
        const inventoryItem = await ctx.db.get(item.inventoryId);
        if (inventoryItem) {
          await ctx.db.patch(item.inventoryId, {
            quantity: inventoryItem.quantity + item.quantity,
          });
        }
      }
    }

    return await ctx.db.delete(args.id);
  },
});

export const getByCustomer = query({
  args: { customerId: v.id("customers") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    return await ctx.db
      .query("orders")
      .withIndex("by_customer", (q) => q.eq("customerId", args.customerId))
      .collect();
  },
});

export const getByStatus = query({
  args: { status: v.string() },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    return await ctx.db
      .query("orders")
      .withIndex("by_status", (q) => q.eq("status", args.status))
      .collect();
  },
});
