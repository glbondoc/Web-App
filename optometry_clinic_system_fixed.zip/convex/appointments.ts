import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";
import { api } from "./_generated/api";

export const list = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const appointments = await ctx.db.query("appointments").order("desc").collect();
    
    const appointmentsWithCustomers = await Promise.all(
      appointments.map(async (appointment) => {
        const customer = await ctx.db.get(appointment.customerId);
        return { ...appointment, customer };
      })
    );

    return appointmentsWithCustomers;
  },
});

export const get = query({
  args: { id: v.id("appointments") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    return await ctx.db.get(args.id);
  },
});

export const getByDate = query({
  args: { date: v.string() },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const appointments = await ctx.db
      .query("appointments")
      .withIndex("by_date", (q) => q.eq("appointmentDate", args.date))
      .collect();

    const appointmentsWithCustomers = await Promise.all(
      appointments.map(async (appointment) => {
        const customer = await ctx.db.get(appointment.customerId);
        return { ...appointment, customer };
      })
    );

    return appointmentsWithCustomers;
  },
});

export const create = mutation({
  args: {
    customerId: v.id("customers"),
    appointmentDate: v.string(),
    appointmentTime: v.string(),
    serviceType: v.string(),
    notes: v.optional(v.string()),
    doctorName: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    // Calculate duration and end time based on service type
    const durations: Record<string, number> = {
      "eye-exam": 60,
      "contact-fitting": 45,
      "frame-selection": 30,
    };
    
    const duration = durations[args.serviceType] || 30;
    const [hours, minutes] = args.appointmentTime.split(':').map(Number);
    const endTime = new Date();
    endTime.setHours(hours, minutes + duration);
    const endTimeString = endTime.toTimeString().slice(0, 5);

    // Generate order number
    const orderNumber = `APT-${Date.now()}`;

    return await ctx.db.insert("appointments", {
      ...args,
      endTime: endTimeString,
      duration,
      status: "scheduled",
      createdBy: userId,
    });
  },
});

export const update = mutation({
  args: {
    id: v.id("appointments"),
    customerId: v.id("customers"),
    appointmentDate: v.string(),
    appointmentTime: v.string(),
    serviceType: v.string(),
    notes: v.optional(v.string()),
    doctorName: v.optional(v.string()),
    status: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const { id, ...updates } = args;
    
    // Recalculate duration and end time
    const durations: Record<string, number> = {
      "eye-exam": 60,
      "contact-fitting": 45,
      "frame-selection": 30,
    };
    
    const duration = durations[args.serviceType] || 30;
    const [hours, minutes] = args.appointmentTime.split(':').map(Number);
    const endTime = new Date();
    endTime.setHours(hours, minutes + duration);
    const endTimeString = endTime.toTimeString().slice(0, 5);

    return await ctx.db.patch(id, {
      ...updates,
      endTime: endTimeString,
      duration,
    });
  },
});

export const remove = mutation({
  args: { id: v.id("appointments") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    return await ctx.db.delete(args.id);
  },
});

export const updateStatus = mutation({
  args: {
    id: v.id("appointments"),
    status: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    return await ctx.db.patch(args.id, { status: args.status });
  },
});

export const checkAvailability = query({
  args: {
    date: v.string(),
    time: v.string(),
    duration: v.number(),
    doctorName: v.optional(v.string()),
    excludeId: v.optional(v.id("appointments")),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const [hours, minutes] = args.time.split(':').map(Number);
    const startTime = hours * 60 + minutes;
    const endTime = startTime + args.duration;

    let query = ctx.db
      .query("appointments")
      .withIndex("by_date", (q) => q.eq("appointmentDate", args.date));

    const appointments = await query.collect();

    const conflicts = appointments.filter(apt => {
      if (args.excludeId && apt._id === args.excludeId) return false;
      if (args.doctorName && apt.doctorName && apt.doctorName !== args.doctorName) return false;
      if (apt.status === "cancelled") return false;

      const [aptHours, aptMinutes] = apt.appointmentTime.split(':').map(Number);
      const aptStartTime = aptHours * 60 + aptMinutes;
      const aptEndTime = aptStartTime + apt.duration;

      return (startTime < aptEndTime && endTime > aptStartTime);
    });

    return {
      available: conflicts.length === 0,
      conflicts: conflicts.length,
    };
  },
});

export const getSuggestedSlots = query({
  args: {
    date: v.string(),
    serviceType: v.string(),
    doctorName: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const durations: Record<string, number> = {
      "eye-exam": 60,
      "contact-fitting": 45,
      "frame-selection": 30,
    };
    
    const duration = durations[args.serviceType] || 30;
    const suggestions = [];

    // Business hours: 9 AM to 6 PM
    for (let hour = 9; hour < 18; hour++) {
      for (let minute = 0; minute < 60; minute += 30) {
        const timeString = `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`;
        
        const availability = await ctx.runQuery(api.appointments.checkAvailability, {
          date: args.date,
          time: timeString,
          duration,
          doctorName: args.doctorName,
        });

        if (availability.available) {
          suggestions.push({ time: timeString });
        }

        if (suggestions.length >= 12) break;
      }
      if (suggestions.length >= 12) break;
    }

    return suggestions;
  },
});

export const getTodaysAppointments = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const today = new Date().toISOString().split('T')[0];
    const appointments = await ctx.db
      .query("appointments")
      .withIndex("by_date", (q) => q.eq("appointmentDate", today))
      .collect();

    const appointmentsWithCustomers = await Promise.all(
      appointments.map(async (appointment) => {
        const customer = await ctx.db.get(appointment.customerId);
        return { ...appointment, customer };
      })
    );

    return appointmentsWithCustomers;
  },
});

export const getAppointmentStats = query({
  args: { startDate: v.string(), endDate: v.string() },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const appointments = await ctx.db.query("appointments").collect();
    const filtered = appointments.filter(apt => 
      apt.appointmentDate >= args.startDate && apt.appointmentDate <= args.endDate
    );

    return {
      total: filtered.length,
      scheduled: filtered.filter(apt => apt.status === "scheduled").length,
      confirmed: filtered.filter(apt => apt.status === "confirmed").length,
      completed: filtered.filter(apt => apt.status === "completed").length,
      cancelled: filtered.filter(apt => apt.status === "cancelled").length,
      noShows: filtered.filter(apt => apt.status === "no-show").length,
    };
  },
});
