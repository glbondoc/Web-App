import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  // Enhanced users table with roles
  profiles: defineTable({
    userId: v.id("users"),
    role: v.string(), // "admin", "staff", "doctor"
    firstName: v.string(),
    lastName: v.string(),
    phone: v.optional(v.string()),
    department: v.optional(v.string()),
    isActive: v.boolean(),
  }).index("by_user", ["userId"])
    .index("by_role", ["role"]),

  customers: defineTable({
    firstName: v.string(),
    lastName: v.string(),
    email: v.string(),
    phone: v.string(),
    dateOfBirth: v.string(),
    address: v.string(),
    emergencyContact: v.string(),
    emergencyPhone: v.string(),
    medicalHistory: v.optional(v.string()),
    lastVisit: v.optional(v.string()),
    preferredContactMethod: v.optional(v.string()), // "email", "sms", "phone"
    notifications: v.optional(v.boolean()),
  }).index("by_email", ["email"])
    .index("by_phone", ["phone"]),

  inventory: defineTable({
    brand: v.string(),
    model: v.string(),
    frameType: v.string(), // "prescription", "sunglasses", "reading", "contact-lenses"
    frameStyle: v.string(), // "full-rim", "semi-rimless", "rimless"
    color: v.string(),
    size: v.string(),
    price: v.number(),
    cost: v.number(),
    quantity: v.number(),
    minStock: v.number(),
    description: v.optional(v.string()),
    supplier: v.optional(v.string()),
    lastRestocked: v.optional(v.string()),
  }).index("by_brand", ["brand"])
    .index("by_frame_type", ["frameType"])
    .index("by_low_stock", ["quantity"]),

  appointments: defineTable({
    customerId: v.id("customers"),
    appointmentDate: v.string(),
    appointmentTime: v.string(),
    endTime: v.string(), // For conflict checking
    serviceType: v.string(), // "eye-exam", "contact-fitting", "frame-selection"
    status: v.string(), // "scheduled", "confirmed", "completed", "cancelled", "no-show"
    notes: v.optional(v.string()),
    doctorName: v.optional(v.string()),
    reminderSent: v.optional(v.boolean()),
    createdBy: v.optional(v.id("users")),
    duration: v.number(), // in minutes
  }).index("by_customer", ["customerId"])
    .index("by_date", ["appointmentDate"])
    .index("by_status", ["status"])
    .index("by_date_time", ["appointmentDate", "appointmentTime"])
    .index("by_doctor", ["doctorName"]),

  // Orders for eyeglasses/contact lenses
  orders: defineTable({
    customerId: v.id("customers"),
    orderNumber: v.string(),
    items: v.array(v.object({
      inventoryId: v.id("inventory"),
      quantity: v.number(),
      price: v.number(),
      itemName: v.string(), // Store item name for reference
    })),
    totalAmount: v.number(),
    status: v.string(), // "pending", "processing", "ready", "completed", "cancelled"
    orderDate: v.string(),
    expectedDate: v.optional(v.string()),
    completedDate: v.optional(v.string()),
    notes: v.optional(v.string()),
    reminderSent: v.optional(v.boolean()),
    createdBy: v.optional(v.id("users")),
  }).index("by_customer", ["customerId"])
    .index("by_status", ["status"])
    .index("by_order_number", ["orderNumber"]),

  // Notifications/Reminders
  notifications: defineTable({
    type: v.string(), // "appointment_reminder", "order_ready", "low_stock"
    recipientId: v.union(v.id("customers"), v.id("users")),
    recipientType: v.string(), // "customer", "staff"
    title: v.string(),
    message: v.string(),
    method: v.string(), // "email", "sms"
    status: v.string(), // "pending", "sent", "failed"
    scheduledFor: v.string(),
    sentAt: v.optional(v.string()),
    relatedId: v.optional(v.union(v.id("appointments"), v.id("orders"))),
  }).index("by_recipient", ["recipientId"])
    .index("by_status", ["status"])
    .index("by_scheduled", ["scheduledFor"]),

  // Analytics data
  analytics: defineTable({
    date: v.string(),
    type: v.string(), // "daily_sales", "appointment_stats", "inventory_movement"
    data: v.object({
      totalSales: v.optional(v.number()),
      appointmentsScheduled: v.optional(v.number()),
      appointmentsCompleted: v.optional(v.number()),
      noShows: v.optional(v.number()),
      newCustomers: v.optional(v.number()),
      inventoryMovement: v.optional(v.array(v.object({
        itemId: v.id("inventory"),
        quantitySold: v.number(),
        revenue: v.number(),
      }))),
    }),
  }).index("by_date", ["date"])
    .index("by_type", ["type"]),

  // System settings
  settings: defineTable({
    key: v.string(),
    value: v.union(v.string(), v.number(), v.boolean()),
    description: v.optional(v.string()),
  }).index("by_key", ["key"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
